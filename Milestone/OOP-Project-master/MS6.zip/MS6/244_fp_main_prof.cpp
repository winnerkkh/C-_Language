// Final Project
// Version 1.0
// Date 2017-08-01
// Author       Fardad Soleimanloo
//
// For you final test before submission:
//      DO NOT MODIFY THIS FILE IN ANY WAY
//
//
// Revision History
// -----------------------------------------------------------
// Name               Date                 Reason
/////////////////////////////////////////////////////////////////
#include "AidApp.h"
int main(){
  sict::AidApp app("244_fp_data.txt");
  return app.run();
}
