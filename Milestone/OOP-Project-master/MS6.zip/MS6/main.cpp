// Final Project Milestone 6
// main.cpp
// Version 1.0
// Date 8/06/2017
// Author Kyunghoon Kim (056-845-100)
// Email Address: khkim12@myseneca.ca
/////////////////////////////////////////////////////////////////

// include AidApp header file
#include "AidApp.h"


using namespace sict;
int main(void) {
	AidApp app("test.txt");
	app.run();
	return 0;
}