// Final Project Milestone 3
// Version 1.0
// Date 7/11/2017
// Author Kyunghoon Kim (056-845-100)
/////////////////////////////////////////////////////////////////


//can't have the same name of ifndef and define with other header file(which is MyFile.h)
#ifndef SICT_STREAMABLE_H_
#define SICT_STREAMABLE_H_

#include <iostream>
#include <fstream> 

namespace sict {
	
	class Streamable {
	
	private:
	
	public:
			std::fstream& store(std::fstream& file, bool addNewLine = true)const;
		    std::fstream& load(std::fstream& file);
			std::ostream& write(std::ostream& os, bool linear)const;
			std::istream& read(std::istream& is);

	};
}
#endif